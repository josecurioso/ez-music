package ezMusic_UI;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.File;


public class Display implements ActionListener
{
	private JFrame frame;
	private JMenuItem openItem;
	private JMenuItem saveItem;
	private JMenuItem exitItem;
	
	public static void main(String[] args) 
	{
		Display display = new Display();
	}

	/**
	 * Shows the display.
	 */
	public Display()
	{
		makeFrame();
	}
	
	/**
	 * Creates the Swing frame and its content.
	 */
	public void makeFrame()
	{
		frame = new JFrame("ezMusic(v1.0)");
		makeMenuBar(frame);
		
		Container contentPane = frame.getContentPane();
		
		JLabel label = new JLabel("Link: ");
		contentPane.add(label);
		
		frame.pack();
		frame.setVisible(true);
	}
	
	/**
	 * Creates the menus' bar.
	 *
	 * @param JFrame frame to be edited.
	 */
	public void makeMenuBar(JFrame frame)
	{
		JMenuBar menubar = new JMenuBar();
		frame.setJMenuBar(menubar);
		//
		JMenu fileMenu = new JMenu("File");
		menubar.add(fileMenu);
		JMenuItem openItem = new JMenuItem("Open");
		openItem.addActionListener(this);
		fileMenu.add(openItem);
		JMenuItem saveItem = new JMenuItem("Save");
		openItem.addActionListener(this);
		fileMenu.add(saveItem);
		//
		JMenu fileMenu2 = new JMenu("Edit");
		menubar.add(fileMenu2);
		JMenuItem undoItem = new JMenuItem("Undo");
		undoItem.addActionListener(this);
		fileMenu2.add(undoItem);
		JMenuItem redoItem = new JMenuItem("Redo");
		redoItem.addActionListener(this);
		fileMenu2.add(redoItem);
		//
		JMenu fileMenu3 = new JMenu("Options");
		menubar.add(fileMenu3);
		JMenuItem customizeItem = new JMenuItem("Customize");
		customizeItem.addActionListener(this);
		fileMenu3.add(customizeItem);
		JMenuItem exitItem = new JMenuItem("Exit");
		exitItem.addActionListener(this);
		fileMenu3.add(exitItem);
		
	}
	
	/**
	 * Notifies you if something has been touched.
	 */
	public void actionPerformed(ActionEvent event)
	{
		System.out.print("Menu item: " + event.getActionCommand());
	}
	
}