package ezMusic_UI;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Display implements ActionListener
{
	public static void main(String[] args) 
	{
		
	}
	
	private JFrame frame;
	
	/**
	 * Shows the display.
	 */
	public Display()
	{
		makeFrame();
	}
	
	/**
	 * Creates the Swing frame and its content.
	 */
	private void makeFrame()
	{
		frame = new JFrame("ezMusic(v1.0)");
		makeMenuBar(frame);
		
		Container contentPane = frame.getContentPane();
		
		JLabel label = new JLabel("Here goes the text");
		contentPane.add(label);
		
		frame.pack();
		frame.setVisible(true);
	}
	
	/**
	 * Creates the menus' bar.
	 *
	 * @param JFrame frame to be edited.
	 */
	private void makeMenuBar(JFrame frame)
	{
		JMenuBar menubar = new JMenuBar();
		frame.setJMenuBar(menubar);
		
		JMenu fileMenu = new JMenu("File");
		menubar.add(fileMenu);
		
		JMenuItem openItem = new JMenuItem("Open");
		openItem.addActionListener(this);
		fileMenu.add(openItem);
		
		JMenuItem quitItem = new JMenuItem("Quit");
		openItem.addActionListener(this);
		fileMenu.add(quitItem);
	}
	
	/**
	 * Notifies you if something has been touched.
	 */
	public void actionPerformed(ActionEvent event)
	{
		System.out.print("Menu item: " + event.getActionCommand());
	}
	
}