package ezMusic_UI;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class Display extends JApplet implements ActionListener
{
	private JFrame frame;
	private JLabel filenameLabel;
	private JLabel statusLabel;
//	private JLabel divisorLabel;
	private FileExplorer explorer;
	
	public static void main(String[] args) 
	{
		Display display = new Display();
	}

	/**
	 * Shows the display.
	 */
	public Display()
	{
		makeFrame(); 
	}
		
	/**
	 * Creates the Swing frame and its content.
	 */
	public void makeFrame()
	{
		frame = new JFrame("ezMusic(v1.0)");
		makeMenuBar(frame);
		
		JPanel contentPane = (JPanel) frame.getContentPane();
		
		contentPane.setBorder(new EmptyBorder(100, 100, 100, 100));
		
		contentPane.setLayout(new BorderLayout(8,8));
		
		buttons();
		
		frame.pack();

		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation(d.width/2 - getWidth()/2, d.height/2 - getHeight()/2);
    	frame.setVisible(true);
	}
	
	/**
	 * Creates the menus' bar.
	 *
	 * @param JFrame frame to be edited.
	 */
	public void makeMenuBar(JFrame frame)
	{
		final int SHORTCUT_MASK = Toolkit.getDefaultToolkit().getMenuShortcutKeyMask();
		
		JMenuBar menubar = new JMenuBar();
		frame.setJMenuBar(menubar);
		//
		JMenu fileMenu = new JMenu("File");
		menubar.add(fileMenu);
		JMenuItem openItem = new JMenuItem("Open");
		
		openItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, SHORTCUT_MASK));
		openItem.addActionListener(e -> openFile());
        fileMenu.add(openItem);		
		JMenuItem saveItem = new JMenuItem("Save");
		saveItem.addActionListener(this);
		fileMenu.add(saveItem);
		//
		JMenu fileMenu2 = new JMenu("Edit");
		menubar.add(fileMenu2);
		
		JMenuItem undoItem = new JMenuItem("Undo");
		undoItem.addActionListener(this);
		fileMenu2.add(undoItem);
		JMenuItem redoItem = new JMenuItem("Redo");
		redoItem.addActionListener(this);
		fileMenu2.add(redoItem);
		//
		JMenu fileMenu3 = new JMenu("Options");
		menubar.add(fileMenu3);
		
		JMenuItem customizeItem = new JMenuItem("Customize");
		customizeItem.addActionListener(this);
		fileMenu3.add(customizeItem);
		JMenuItem quitItem = new JMenuItem("Quit");
		quitItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q, SHORTCUT_MASK));
		quitItem.addActionListener(e -> quit());		
		fileMenu3.add(quitItem);
		
	}
	
	/**
	 * Notifies you if something has been touched.
	 */
	public void actionPerformed(ActionEvent event)
	{
		System.out.print("Menu item: " + event.getActionCommand());
	}
	
	public void buttons()
	{
		Container contentPane = frame.getContentPane();
		filenameLabel = new JLabel("Archivos...");
		contentPane.add(filenameLabel, BorderLayout.WEST);
		
		statusLabel = new JLabel("Esperando...");
		contentPane.add(statusLabel, BorderLayout.EAST);
		
//		String aux = "";
//		
//		for(int i = 0; i < 100; i++)
//		{
//			aux = aux + "|";
//		}
//		
//		divisorLabel = new JLabel(aux);
//		contentPane.add(divisorLabel, BorderLayout.CENTER);
	}
	
	/**
     * Quit function: quit the application.
     */
    private void quit()
    {
        System.exit(0);
    }
    
    /**
     * Open function: open a file chooser to select a new image file.
     */
    private void openFile()
    {
        //System.out.println("Open file!");
    	FileExplorer.main(null);
    }
}