package download;
 
import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;
import org.json.JSONObject;

import com.google.gdata.data.youtube.PlaylistEntry;
import com.google.gdata.data.youtube.PlaylistFeed;


import com.google.gdata.client.*;
import com.google.gdata.client.youtube.*;
import com.google.gdata.data.*;
import com.google.gdata.data.geo.impl.*;
import com.google.gdata.data.media.*;
import com.google.gdata.data.media.mediarss.*;
import com.google.gdata.data.youtube.*;
import com.google.gdata.data.extensions.*;
import com.google.gdata.util.*;
import java.io.IOException;
import java.io.File;
import java.net.URL;



import org.apache.commons.io.IOUtils;
 
public class HttpDownloader {
 
		
	
	
    public static void main(String[] args) {
    	String playlistUrl = "https://www.youtube.com/playlist?list=PL9fZWvwimefvgG334_-8hDrTzN8EY2j0N";
    	
    	
    	
    	
    	try{
    		YouTubeService service = new YouTubeService("99205612302-0ol8hmf4es0u1vjmmr28cfm4o4dshps0.apps.googleusercontent.com", "AIzaSyB-0w6c7lz4DNWcS4blcHFrb3xl_AkGsvk");
        	//service.setUserCredentials("jotajotanora@gmail.com", "pass");
    		String playlistUrl = entry.getFeedUrl();
    		PlaylistFeed playlistFeed = service.getFeed(new URL(playlistUrl), PlaylistFeed.class);
    		for(PlaylistEntry playlistEntry : playlistFeed.getEntries()) {
    			System.out.println("Title: " + playlistEntry.getTitle().getPlainText());
    			System.out.println("Description: " + playlistEntry.getSummary().getPlainText());
    			System.out.println("Position: " + playlistEntry.getPosition());
    			System.out.println("Video URL: " + playlistEntry.getHtmlLink().getHref());
    		}
    	}
    	catch(Exception e){
    		System.out.println("Error");
    		e.printStackTrace();
    	}
    	
    	
    	
    	
//    	String argument = args[0];
//    	if(argument.contains("youtube.com") && argument.contains("watch?v=")){
//    		download(argument);
//    	}
//    	else if(argument.contains("youtube.com") && argument.contains("playlist?list=")){
//    		//Do something with youtube API
//    	}
    }
    
    
    public static void download(String videoURL){
    	String saveDir = "D:/Escritorio/Prueba";
    	String downloadURL = "";
    	JSONObject info = getInfo(videoURL);
        try {
        	downloadURL = info.getString("link");
        	HttpDownloadUtility.downloadFile(downloadURL, saveDir);
    		System.out.println();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static JSONObject getInfo(String videoURL){
    	String infoURL = "http://www.youtubeinmp3.com/fetch/?format=json&video=";
    	try{
    		JSONObject json = new JSONObject(IOUtils.toString(new URL(infoURL+videoURL), Charset.forName("UTF-8")));
        	return json;
    	} catch (Exception e) {
    	    return null;
    	}
    }
}